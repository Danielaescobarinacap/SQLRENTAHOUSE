-- 04) Clasificación masiva inicial
-- Motivo: generar datos en CLIENTE_FIDELIZADO para todo el universo de clientes
BEGIN
  pkg_fidelizacion_cliente.clasificar_todos;
END;
/
