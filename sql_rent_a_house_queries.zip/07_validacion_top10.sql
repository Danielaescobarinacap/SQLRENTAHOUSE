-- 07) Validación: Top 10 por arrendos (desempate por renta/fecha)
-- Motivo: revisar principales clientes fidelizados
SELECT numrut_cli, categoria, arrendos, renta_cli, fecha_clasificacion
FROM cliente_fidelizado
ORDER BY arrendos DESC, renta_cli DESC, fecha_clasificacion DESC
FETCH FIRST 10 ROWS ONLY;
