-- 11) Vista de consumo para BI/Aplicaciones
-- Motivo: exponer datos de clientes con su categoría de fidelización
CREATE OR REPLACE VIEW v_clientes_fidelizados AS
SELECT c.numrut_cli,
       c.nom_cli,
       c.apepat_cli,
       c.apemat_cli,
       cf.categoria,
       cf.arrendos,
       cf.renta_cli,
       cf.fecha_clasificacion
FROM cliente c
JOIN cliente_fidelizado cf ON cf.numrut_cli = c.numrut_cli;
-- Prueba rápida
SELECT * FROM v_clientes_fidelizados FETCH FIRST 10 ROWS ONLY;
