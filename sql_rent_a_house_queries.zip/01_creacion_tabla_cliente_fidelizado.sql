-- 01) Creación de tabla auxiliar para persistir la clasificación
-- Motivo: almacenar la categoría de fidelización, métricas y trazabilidad de la regla aplicada
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE cliente_fidelizado CASCADE CONSTRAINTS';
EXCEPTION
  WHEN OTHERS THEN 
    IF SQLCODE != -942 THEN RAISE; END IF; -- ignora tabla inexistente
END;
/
CREATE TABLE cliente_fidelizado (
  numrut_cli          NUMBER(10)   CONSTRAINT pk_cliente_fidelizado PRIMARY KEY,
  categoria           VARCHAR2(10) CONSTRAINT ck_cat CHECK (categoria IN ('PREMIUM','FRECUENTE','ESTANDAR')),
  arrendos            NUMBER(5)    NOT NULL,
  renta_cli           NUMBER(10)   NOT NULL,
  fecha_clasificacion DATE         DEFAULT SYSDATE NOT NULL,
  regla_usada         VARCHAR2(200)
);
CREATE INDEX ix_cli_fid_categoria ON cliente_fidelizado (categoria);
/