-- 02) Especificación del package (interfaz pública)
-- Motivo: declarar procedimientos/funciones disponibles al resto del sistema
CREATE OR REPLACE PACKAGE pkg_fidelizacion_cliente AS
  PROCEDURE clasificar_cliente(p_numrut_cli IN cliente.numrut_cli%TYPE);
  PROCEDURE clasificar_todos;
  FUNCTION  obtener_categoria(p_numrut_cli IN cliente.numrut_cli%TYPE) RETURN VARCHAR2;
  PROCEDURE reporte_fidelizados(p_detalle BOOLEAN DEFAULT TRUE);
END pkg_fidelizacion_cliente;
/
SHOW ERRORS PACKAGE pkg_fidelizacion_cliente;
/