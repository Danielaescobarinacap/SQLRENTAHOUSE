-- 03) Cuerpo del package (lógica de negocio)
-- Motivo: implementar reglas, cálculos, upsert y reportes
CREATE OR REPLACE PACKAGE BODY pkg_fidelizacion_cliente AS

  FUNCTION f_categoria(p_arrendos NUMBER, p_renta NUMBER, p_regla OUT VARCHAR2)
    RETURN VARCHAR2
  IS
    v_cat VARCHAR2(10);
  BEGIN
    IF p_arrendos >= 3 AND p_renta >= 1500000 THEN
      v_cat := 'PREMIUM';   p_regla := 'Arrendos>=3 y Renta>=1.500.000';
    ELSIF p_arrendos >= 2 OR p_renta >= 1200000 THEN
      v_cat := 'FRECUENTE'; p_regla := 'Arrendos>=2 o Renta>=1.200.000';
    ELSE
      v_cat := 'ESTANDAR';  p_regla := 'Resto';
    END IF;
    RETURN v_cat;
  END f_categoria;

  PROCEDURE p_calcula_metricas(
    p_numrut_cli IN  cliente.numrut_cli%TYPE,
    p_arrendos   OUT NUMBER,
    p_renta      OUT NUMBER
  ) IS
  BEGIN
    SELECT renta_cli
      INTO p_renta
      FROM cliente
     WHERE numrut_cli = p_numrut_cli;

    SELECT NVL(COUNT(*),0)
      INTO p_arrendos
      FROM propiedad_arrendada
     WHERE numrut_cli = p_numrut_cli;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20001, 'Cliente '||p_numrut_cli||' no encontrado en CLIENTE.');
    WHEN OTHERS THEN
      RAISE;
  END p_calcula_metricas;

  PROCEDURE clasificar_cliente(p_numrut_cli IN cliente.numrut_cli%TYPE) IS
    v_arrendos NUMBER;
    v_renta    NUMBER;
    v_cat      VARCHAR2(10);
    v_regla    VARCHAR2(200);
  BEGIN
    p_calcula_metricas(p_numrut_cli, v_arrendos, v_renta);
    v_cat := f_categoria(v_arrendos, v_renta, v_regla);

    MERGE INTO cliente_fidelizado cf
    USING (SELECT p_numrut_cli AS numrut_cli,
                  v_cat        AS categoria,
                  v_arrendos   AS arrendos,
                  v_renta      AS renta_cli,
                  SYSDATE      AS fecha_clasificacion,
                  v_regla      AS regla_usada
             FROM dual) src
       ON (cf.numrut_cli = src.numrut_cli)
     WHEN MATCHED THEN
       UPDATE SET cf.categoria           = src.categoria,
                  cf.arrendos            = src.arrendos,
                  cf.renta_cli           = src.renta_cli,
                  cf.fecha_clasificacion = src.fecha_clasificacion,
                  cf.regla_usada         = src.regla_usada
     WHEN NOT MATCHED THEN
       INSERT (numrut_cli, categoria, arrendos, renta_cli, fecha_clasificacion, regla_usada)
       VALUES (src.numrut_cli, src.categoria, src.arrendos, src.renta_cli, src.fecha_clasificacion, src.regla_usada);

  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR] clasificar_cliente('||p_numrut_cli||'): '||SQLERRM);
      RAISE;
  END clasificar_cliente;

  PROCEDURE clasificar_todos IS
  BEGIN
    FOR r IN (SELECT numrut_cli FROM cliente) LOOP
      BEGIN
        clasificar_cliente(r.numrut_cli);
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE('[WARN] Cliente '||r.numrut_cli||' omitido: '||SQLERRM);
      END;
    END LOOP;
    COMMIT;
  END clasificar_todos;

  FUNCTION obtener_categoria(p_numrut_cli IN cliente.numrut_cli%TYPE)
    RETURN VARCHAR2
  IS
    v_cat VARCHAR2(10);
  BEGIN
    BEGIN
      SELECT categoria INTO v_cat
        FROM cliente_fidelizado
       WHERE numrut_cli = p_numrut_cli;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        clasificar_cliente(p_numrut_cli);
        SELECT categoria INTO v_cat
          FROM cliente_fidelizado
         WHERE numrut_cli = p_numrut_cli;
    END;
    RETURN v_cat;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20002, 'No existe el cliente '||p_numrut_cli||' en CLIENTE.');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR] obtener_categoria('||p_numrut_cli||'): '||SQLERRM);
      RAISE;
  END obtener_categoria;

  PROCEDURE reporte_fidelizados(p_detalle BOOLEAN DEFAULT TRUE) IS
    v_total NUMBER;
  BEGIN
    DBMS_OUTPUT.PUT_LINE('===== REPORTE DE CLIENTES FIDELIZADOS =====');
    SELECT COUNT(*) INTO v_total FROM cliente_fidelizado;
    DBMS_OUTPUT.PUT_LINE('Total clientes clasificados: '||v_total);

    FOR r IN (
      SELECT categoria, COUNT(*) cnt
        FROM cliente_fidelizado
       GROUP BY categoria
       ORDER BY CASE categoria WHEN 'PREMIUM' THEN 1 WHEN 'FRECUENTE' THEN 2 ELSE 3 END
    ) LOOP
      DBMS_OUTPUT.PUT_LINE('- '||r.categoria||': '||r.cnt);
    END LOOP;

    IF p_detalle THEN
      DBMS_OUTPUT.PUT_LINE(chr(10)||'-- Detalle (Top 20 por arrendos, desempate por renta) --');
      FOR d IN (
        SELECT *
          FROM (
            SELECT numrut_cli, categoria, arrendos, renta_cli, fecha_clasificacion
              FROM cliente_fidelizado
             ORDER BY arrendos DESC, renta_cli DESC, fecha_clasificacion DESC
          )
         WHERE ROWNUM <= 20
      ) LOOP
        DBMS_OUTPUT.PUT_LINE(
          'CLI='||d.numrut_cli||
          ' | CAT='||d.categoria||
          ' | ARRENDOS='||d.arrendos||
          ' | RENTA='||TO_CHAR(d.renta_cli,'L999G999G999')||
          ' | CLASIF='||TO_CHAR(d.fecha_clasificacion,'YYYY-MM-DD')
        );
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR] reporte_fidelizados: '||SQLERRM);
      RAISE;
  END reporte_fidelizados;

END pkg_fidelizacion_cliente;
/
SHOW ERRORS PACKAGE BODY pkg_fidelizacion_cliente;
/