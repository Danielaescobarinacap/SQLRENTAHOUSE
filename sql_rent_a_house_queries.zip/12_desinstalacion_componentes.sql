-- 12) Desinstalación/rollback rápido
-- Motivo: limpiar objetos si es necesario revertir
BEGIN
  DBMS_SCHEDULER.drop_job('JOB_RECLASIF_CLIENTES', TRUE);
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
DROP VIEW v_clientes_fidelizados;
DROP PACKAGE pkg_fidelizacion_cliente;
DROP TABLE cliente_fidelizado CASCADE CONSTRAINTS;
