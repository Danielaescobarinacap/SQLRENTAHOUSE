-- 05) Reporte de fidelización (resumen + top 20)
-- Motivo: validar en consola el total y la distribución por categoría
SET SERVEROUTPUT ON
BEGIN
  DBMS_OUTPUT.ENABLE(NULL);
  pkg_fidelizacion_cliente.reporte_fidelizados(p_detalle => TRUE);
END;
/
