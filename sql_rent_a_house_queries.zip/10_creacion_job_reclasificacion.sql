-- 10) Automatización con DBMS_SCHEDULER
-- Motivo: reclasificar diariamente a las 02:00
BEGIN
  DBMS_SCHEDULER.create_job (
    job_name        => 'JOB_RECLASIF_CLIENTES',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN pkg_fidelizacion_cliente.clasificar_todos; END;',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=DAILY;BYHOUR=2;BYMINUTE=0;BYSECOND=0',
    enabled         => TRUE,
    comments        => 'Reclasifica clientes a diario a las 02:00'
  );
END;
/
-- Ver estado
SELECT job_name, state, last_start_date, last_run_duration
FROM user_scheduler_jobs
WHERE job_name = 'JOB_RECLASIF_CLIENTES';
