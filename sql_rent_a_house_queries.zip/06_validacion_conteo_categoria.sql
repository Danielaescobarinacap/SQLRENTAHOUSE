-- 06) Validación: conteo por categoría
-- Motivo: ver distribución de clientes por segmento
SELECT categoria, COUNT(*) clientes
FROM cliente_fidelizado
GROUP BY categoria
ORDER BY CASE categoria WHEN 'PREMIUM' THEN 1 WHEN 'FRECUENTE' THEN 2 ELSE 3 END;
