-- 09) Permisos para usuarios de aplicación/BI
-- Motivo: habilitar lectura/ejecución del módulo
-- Reemplaza app_user por el usuario destinatario
GRANT SELECT ON cliente TO app_user;
GRANT SELECT ON propiedad_arrendada TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON cliente_fidelizado TO app_user;
GRANT EXECUTE ON pkg_fidelizacion_cliente TO app_user;
