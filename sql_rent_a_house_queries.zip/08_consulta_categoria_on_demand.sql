-- 08) Consulta puntual de categoría (autoclasiﬁca si no existe)
-- Motivo: demostrar uso de la función en línea
-- Reemplaza <NUMRUT> por un identificador válido
SELECT pkg_fidelizacion_cliente.obtener_categoria(<NUMRUT>) AS categoria FROM dual;
